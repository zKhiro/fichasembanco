How to run concat command from a csv file (see the test_csv.png):
- move to the "bin" pdfsam subdirectory
- (win32) run the command: run-console.bat -l f:\YOUR_CSV_FILE.csv -o c:\output.pdf concat
- (nix) run the command: ./run-console.sh -l f:\YOUR_CSV_FILE.csv -o c:\output.pdf concat

How to run concat command from an xml file (see the test_xml.png):
- move to the "bin" pdfsam subdirectory
- (win32) run the command: run-console.bat -l f:\YOUR_XML_FILE.xml -o c:\output.pdf concat
- (nix) run the command: ./run-console.sh -l f:\YOUR_XML_FILE.xml -o c:\output.pdf concat
